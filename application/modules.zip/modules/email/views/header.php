<!-- <html>
<head></head>
<body> -->
<style>
[title="mailbg"] >div{
	background-size:100% 100% !important;
	transition:0.4s ease;
}
[title="mailbg"]:hover  >div{
	background-size:110% 110% !important;
}
</style>
<div title="mailbg"
style="font-family: Roboto;margin:auto;background-color:#fff;border:1px solid #e9e9e9;border-radius:6px;overflow:hidden;margin: 1vw 6vw;border-collapse:separate;box-shadow: 0 0 2px #0000001c;" width="650">
	<div style="width:100%;background-image: linear-gradient(23deg, rgba(202, 202, 202,0.02) 0%, rgba(202, 202, 202,0.02) 13%,transparent 13%, transparent 80%,rgba(11, 11, 11,0.02) 80%, rgba(11, 11, 11,0.02) 100%),linear-gradient(42deg, rgba(98, 98, 98,0.02) 0%, rgba(98, 98, 98,0.02) 36%,transparent 36%, transparent 77%,rgba(252, 252, 252,0.02) 77%, rgba(252, 252, 252,0.02) 100%),linear-gradient(286deg, rgba(173, 173, 173,0.02) 0%, rgba(173, 173, 173,0.02) 2%,transparent 2%, transparent 12%,rgba(59, 59, 59,0.02) 12%, rgba(59, 59, 59,0.02) 100%),linear-gradient(77deg, rgba(87, 87, 87,0.02) 0%, rgba(87, 87, 87,0.02) 18%,transparent 18%, transparent 55%,rgba(247, 247, 247,0.02) 55%, rgba(247, 247, 247,0.02) 100%),linear-gradient(90deg, rgb(255,255,255),rgb(255,255,255));" width="100%">
		<div
			style="color:#4f4f4f;padding-bottom:15px;padding-top:15px;text-align:center;border-bottom: 1px solid #eee;background: #8fd1ff87;"
			align="center">
			<span style="color: #36a2eb;font-family: Roboto;letter-spacing: 1px;font-weight: 400;font-size: 38px;" >MOBITRADOS</span>
			<div>
			<span style="color: #606975;font-family: Roboto;letter-spacing: 1px;font-weight: 300;font-size: 11px;text-transform: none;" >Mob:  212 123 456 789</span>
			<span style="color: #606975;font-family: Roboto;letter-spacing: 1px;font-weight: 300;font-size: 11px;text-transform: none;" >| </span>
			<span style="color: #606975;font-family: Roboto;letter-spacing: 1px;font-weight: 300;font-size: 11px;text-transform: none;" >Email:  support@mobitrados.com</span>
			</div>
		</div>
		<div style="text-align:center;border: 1px solid #eee;" align="center">
			<span style="color: #606975;font-family: Roboto;" ><?=@$head?></span>
		</div>

		<div style="text-align:left;padding: 20px;color: #847286;" align="left">
