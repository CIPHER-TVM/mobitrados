<?php defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
class Public_api extends REST_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('public_api_model');
		date_default_timezone_set('Asia/Calcutta');
	}

	public function index_get()
	 {
			$this->response(array('status' => 103, 'result' => 'Unknown Method'), REST_Controller::HTTP_NOT_FOUND);
	 }
	 public function index_post()
	 {
			$this->response(array('status' => 103, 'result' => 'Unknown Methodx'), REST_Controller::HTTP_NOT_FOUND);
	 }

	 public function app_version_get()
	 {
		 $response=array();
		 $version=getAfield("version","app_version","where id=1");
		 $response['app_version']=$version;
		 $this->response(array('status' => 200, 'message' => "Success" ,'response'=>$response ), REST_Controller::HTTP_OK);
	 }
}
