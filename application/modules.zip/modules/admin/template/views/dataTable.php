<link rel="stylesheet" href="<?php echo base_url() ?>assets/admin_template/plugins/datatables/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/admin_template/plugins/datatables/responsive.bootstrap4.min.css">
	
  <!-- Plugins -->
  <script src="<?php echo base_url() ?>assets/admin_template/plugins/datatables/jquery.dataTables.bootstrap4.responsive.min.js"></script>