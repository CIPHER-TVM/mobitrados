<!-- Main Scripts -->
<script src="<?php echo base_url() ?>assets/admin_template/dist/js/script.min.js"></script>
<script src="<?php echo base_url() ?>assets/admin_template/dist/js/app.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin_template/plugins/bootstrap-select/bootstrap-select.min.js"></script>
<!-- <script src="<?php echo base_url() ?>assets/admin_template/plugins/bootstrap-select/bootstrap-select.min.js"></script>
<script src="<?php echo base_url() ?>assets/admin_template/plugins/clockpicker/bootstrap-clockpicker.min.js"></script> -->
