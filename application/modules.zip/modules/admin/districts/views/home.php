<main>
    
</main>
<script>
    var base_url = '<?php echo base_url(); ?>';
</script>