<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Public_api_model extends CI_Model {

}
