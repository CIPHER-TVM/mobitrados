<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="icon" href="<?php echo base_url(); ?>assets/web_userfiles\assets\images\favicon.ico" type="image/x-icon">
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800" rel="stylesheet">
<!-- Required Fremwork -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\bootstrap\css\bootstrap.min.css">
<!-- radial chart.css -->
<!--<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web_user/files\assets\pages\chart\radial\css\radial.css" type="text/css" media="all"> -->
<!-- feather Awesome -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\icon\themify-icons\themify-icons.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\icon\icofont\css\icofont.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\icon\font-awesome\css\font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\icon\feather\css\feather.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\select2\css\select2.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\bootstrap-multiselect\css\bootstrap-multiselect.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\multiselect\css\">


<!-- Switch component css -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\switchery\css\switchery.min.css">
<!-- Tags css -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\bootstrap-tagsinput\css\bootstrap-tagsinput.css">

<!-- Multi Select css -->


<!-- Style.css -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\css\style.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\css\jquery.mCustomScrollbar.css">


<!-- sweet alert framework -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\sweetalert\css\sweetalert.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\css\component.css">

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\assets\pages\notification\notification.css">
<!-- Animate.css -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/files\bower_components\animate.css\css\animate.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/admin_template/dist/css/custom.css">
<link rel="stylesheet" href="#" id="sidebar-css">

<!--<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/web_user/datepicker/datepicker.css"> -->

  <style>
.select2-container--default .select2-selection--single .select2-selection__rendered {
    background-color: #FFFFFF;
    color: #000000;
    /* padding: 8px 30px 8px 20px; */
    padding: .25rem .5rem;
        height: calc(1.8125rem + 2px);
}

.select2-container--default .select2-selection--single .select2-selection__arrow b {
    border-color: #000 transparent transparent transparent;
    border-style: solid;
    border-width: 5px 4px 0 4px;
    height: 0;
    left: 50%;
    margin-left: -4px;
    margin-top: -2px;
    position: absolute;
    top: 33%;
    width: 0;

}
.font-sm{
  font-size: 14px;
}

.select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow b {
     border-color: transparent transparent #fff transparent;
}
.select2-container--default .select2-selection--single {
    background-color: #fff;
    border: 1px solid #aaa;
     border-radius: 2px;
}
.star
{
  color:red;
}
.swal2-container {
  z-index: X;
}
</style>
