<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Category extends MY_Controller {
    public function __construct()
    {
        parent::__construct();
    }
    public function index() {
        $data['page'] = 'catagory';
        $data['mainpage'] = '';
        $data['page_title'] = 'Add Category';
        $data['cs']=120;
        $this->template->page_maker('category/home',$data);
    }
    public function GetAllCatagory() {
        $this->load->model('catagoryModel');
        echo $this->catagoryModel->GetAllCatagory();
    }
    public function GetAllCatagoryDT() {
        $this->load->model('catagoryModel');
        echo $this->catagoryModel->GetAllCatagoryDT();

    }
    public function GetCatagoryById() {
        $this->load->model('catagoryModel');
        echo $this->catagoryModel->GetCatagoryById($this->input->post('pcid'));
    }
    public function AddCatagory() {
        $dataToSave['product_catogory_name'] = $this->input->post('catagoryName');
        $dataToSave['display_status'] = $this->input->post('displayStatus');
        $this->load->model('catagoryModel');
        echo $this->catagoryModel->AddCatagory($dataToSave);
    }

    public function UpdateCatagory() {

        $dataToUpdate['product_catogory_name'] = $this->input->post('catagoryName');
        $dataToUpdate['display_status'] = $this->input->post('displayStatus');

        $this->load->model('catagoryModel');
        echo $this->catagoryModel->UpdateCatagory($dataToUpdate, $this->input->post('pcid'));
    }

    public function DeleteCatagory() {

        $this->load->model('catagoryModel');
        echo $this->catagoryModel->DeleteCatagory($this->input->post('pcid'));
    }

    public function logout() {
        $user_data = $this->session->all_userdata();
        foreach ($user_data as $key => $value)
            $this->session->unset_userdata($key);
        $this->session->sess_destroy();
        $url=admin_url();
        $url.="home";
        redirect($url);

    }
}
