<?php
    class StatesObject
    {
        public $SerialNo;
        public $StateID;
        public $CountryID;
        public $StateName;
        public $DisplayStatus;
        public $EditInnerHTML;
        public $DeleteInnerHTML;
    }
?>