  <style>
	.copyright{

	}
	</style>
	<div class="sidebar-backdrop" id="sidebarBackdrop" data-toggle="sidebar"></div>
</body>
<script>

$('#ar_loader').hide();
</script>

</html>
