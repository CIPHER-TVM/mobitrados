<p style="font-size:16px;line-height:24px;margin:0;text-align:left" align="left">Hello <?=$name?>,</p>
<br>
<p style="font-size:16px;line-height:24px;margin:0;text-align:left" align="left"> Welcome to Citymedshop! We are glad
	to have you onboard.<br>
<p style="font-size:16px;line-height:24px;margin:0;text-align:left" align="left">Your order for medicines (OrderNo <?=$order_no?>) has been approved by shop. Your order total is <?=$total?>/-. Go to order details and confirm your order to deliver your medicine </b>.<br>
</p>
<br>
<p style="font-size:16px;line-height:24px;margin:0;text-align:left" align="left"> Thanks, Citymedshop Team </p>