<?php
    class DistrictsObject
    {
        public $DistrictId;
        public $DistrictName;
        public $DisplayStatus;
        public $StateID;
    }
?>