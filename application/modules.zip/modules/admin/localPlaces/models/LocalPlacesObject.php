<?php
    class LocalPlacesObject
    {
        public $PlaceID;
        public $PlaceName;
        public $DisplayStatus;
        public $DistrictID;
        public $pincode;
    }
?>
